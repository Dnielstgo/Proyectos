"""
gui.py - Interfaz Gráfica de la Simulación
==========================================
Interfaz completa con:
  - Visualización 2D de la mano en tiempo real
  - Panel de control de modos
  - Controles de patrones de agarre
  - Visualización de señales EMG
  - Control individual de dedos
  - Telemetría y estadísticas
  - Log de eventos
"""

import tkinter as tk
from tkinter import ttk, font as tkfont
import math
import time
import threading
from typing import Dict, List, Tuple, Optional

from controller import ProthesisController, ControlMode
from hand_model import FingerName, GripPattern, HandModel
from sensors import MuscleGroup


# ─── Paleta de colores ───────────────────────────────────────────────────────
COLORS = {
    "bg_dark":      "#0D1117",
    "bg_panel":     "#161B22",
    "bg_widget":    "#1C2128",
    "border":       "#30363D",
    "accent_blue":  "#58A6FF",
    "accent_green": "#3FB950",
    "accent_orange":"#F78166",
    "accent_yellow":"#E3B341",
    "accent_purple":"#BC8CFF",
    "text_primary": "#E6EDF3",
    "text_secondary":"#8B949E",
    "text_muted":   "#484F58",
    "skin_light":   "#FDBCB4",
    "skin_mid":     "#F0917A",
    "skin_dark":    "#D4735A",
    "joint_color":  "#58A6FF",
    "bone_color":   "#C9D1D9",
    "palm_fill":    "#2A3441",
    "palm_stroke":  "#3FB950",
    "emg_active":   "#3FB950",
    "emg_inactive": "#21262D",
    "fatigue_low":  "#3FB950",
    "fatigue_mid":  "#E3B341",
    "fatigue_high": "#F78166",
}


class HandCanvas(tk.Canvas):
    """
    Canvas especializado para renderizar la mano protésica en 2D.
    Dibuja la palma, dedos con cinemática directa, articulaciones y efectos.
    """
    
    SCALE = 1.5       # Factor de escala visual
    OFFSET_X = 20     # Desplazamiento X
    OFFSET_Y = 80     # Desplazamiento Y
    
    FINGER_WIDTHS = {
        FingerName.THUMB:  10,
        FingerName.INDEX:  9,
        FingerName.MIDDLE: 9,
        FingerName.RING:   8,
        FingerName.LITTLE: 7,
    }
    
    FINGER_COLORS = {
        FingerName.THUMB:  "#E8A090",
        FingerName.INDEX:  "#EAA898",
        FingerName.MIDDLE: "#ECADA0",
        FingerName.RING:   "#EAAA9C",
        FingerName.LITTLE: "#E6A08A",
    }
    
    def __init__(self, parent, hand_model: HandModel, **kwargs):
        super().__init__(parent, **kwargs)
        self.hand = hand_model
        self.configure(
            bg=COLORS["bg_dark"],
            highlightthickness=1,
            highlightbackground=COLORS["border"]
        )
    
    def render(self):
        """Renderiza el estado actual de la mano."""
        self.delete("all")
        self._draw_background_grid()
        self._draw_palm()
        self._draw_wrist()
        
        # Dibujar dedos (de atrás hacia adelante)
        order = [FingerName.LITTLE, FingerName.RING, FingerName.MIDDLE, 
                 FingerName.INDEX, FingerName.THUMB]
        for finger_name in order:
            self._draw_finger(finger_name)
        
        self._draw_labels()
        self._draw_grip_info()
    
    def _draw_background_grid(self):
        """Cuadrícula de fondo sutil."""
        w = int(self.cget("width"))
        h = int(self.cget("height"))
        grid_color = "#1A2030"
        
        for x in range(0, w, 30):
            self.create_line(x, 0, x, h, fill=grid_color, width=1)
        for y in range(0, h, 30):
            self.create_line(0, y, w, y, fill=grid_color, width=1)
        
        # Borde con glow
        self.create_rectangle(2, 2, w-2, h-2, 
                              outline=COLORS["accent_green"], width=1,
                              dash=(4, 8))
    
    def _draw_palm(self):
        """Dibuja la palma de la mano con forma realista."""
        # Palma principal
        palm_points = [
            (60*self.SCALE + self.OFFSET_X,  200*self.SCALE + self.OFFSET_Y),
            (100*self.SCALE + self.OFFSET_X, 130*self.SCALE + self.OFFSET_Y),
            (280*self.SCALE + self.OFFSET_X, 135*self.SCALE + self.OFFSET_Y),
            (295*self.SCALE + self.OFFSET_X, 200*self.SCALE + self.OFFSET_Y),
            (280*self.SCALE + self.OFFSET_X, 260*self.SCALE + self.OFFSET_Y),
            (70*self.SCALE + self.OFFSET_X,  260*self.SCALE + self.OFFSET_Y),
        ]
        
        flat_points = [coord for point in palm_points for coord in point]
        
        # Sombra
        shadow_points = [p + 4 for p in flat_points]
        self.create_polygon(shadow_points, fill="#050810", outline="", smooth=True)
        
        # Palma
        self.create_polygon(flat_points, fill=COLORS["palm_fill"], 
                           outline=COLORS["palm_stroke"], width=2, smooth=True)
        
        # Líneas de la palma (detalles)
        def palm_line(x1, y1, x2, y2):
            self.create_line(
                x1*self.SCALE+self.OFFSET_X, y1*self.SCALE+self.OFFSET_Y,
                x2*self.SCALE+self.OFFSET_X, y2*self.SCALE+self.OFFSET_Y,
                fill=COLORS["border"], width=1, dash=(3, 5)
            )
        
        palm_line(90, 200, 180, 230)
        palm_line(130, 160, 200, 240)
    
    def _draw_wrist(self):
        """Dibuja el área de la muñeca."""
        wx = 175*self.SCALE + self.OFFSET_X
        wy = 265*self.SCALE + self.OFFSET_Y
        
        # Rectángulo de muñeca
        self.create_rectangle(
            70*self.SCALE+self.OFFSET_X,  260*self.SCALE+self.OFFSET_Y,
            280*self.SCALE+self.OFFSET_X, 290*self.SCALE+self.OFFSET_Y,
            fill="#1A2535", outline=COLORS["border"], width=1
        )
        
        # Indicador de ángulo de muñeca
        wrist_angle = self.hand.wrist_angle
        color = COLORS["accent_yellow"] if abs(wrist_angle) > 5 else COLORS["text_muted"]
        self.create_text(wx, wy+15, text=f"Muñeca: {wrist_angle:+.0f}°",
                        fill=color, font=("Courier", 8))
        
        # Línea decorativa del socket
        for x in range(80, 280, 15):
            sx = x*self.SCALE+self.OFFSET_X
            self.create_line(sx, 288*self.SCALE+self.OFFSET_Y,
                           sx+5, 298*self.SCALE+self.OFFSET_Y,
                           fill=COLORS["border"], width=1)
    
    def _draw_finger(self, finger_name: FingerName):
        """Dibuja un dedo con sus segmentos y articulaciones."""
        finger = self.hand.fingers[finger_name]
        keypoints_raw = finger.get_keypoints(scale=1.0)
        
        # Aplicar escala y offset
        keypoints = [
            (x*self.SCALE + self.OFFSET_X, y*self.SCALE + self.OFFSET_Y)
            for x, y in keypoints_raw
        ]
        
        base_color = self.FINGER_COLORS[finger_name]
        width = self.FINGER_WIDTHS[finger_name]
        grip_level = finger.joints.grip_level
        
        # Color varía con el nivel de agarre
        if grip_level > 0.7:
            seg_color = COLORS["skin_dark"]
        elif grip_level > 0.3:
            seg_color = COLORS["skin_mid"]
        else:
            seg_color = base_color
        
        # Dibujar segmentos como líneas gruesas redondeadas
        for i in range(len(keypoints) - 1):
            x1, y1 = keypoints[i]
            x2, y2 = keypoints[i + 1]
            
            # Sombra del segmento
            self.create_line(x1+2, y1+2, x2+2, y2+2,
                           fill="#050810", width=width+2,
                           capstyle=tk.ROUND, joinstyle=tk.ROUND)
            
            # Segmento principal
            seg_width = max(4, width - i)
            self.create_line(x1, y1, x2, y2,
                           fill=seg_color, width=seg_width,
                           capstyle=tk.ROUND, joinstyle=tk.ROUND)
            
            # Línea de detalle (tendón)
            self.create_line(x1, y1, x2, y2,
                           fill=COLORS["bg_dark"], width=1,
                           capstyle=tk.ROUND, dash=(2, 4))
        
        # Dibujar articulaciones (círculos)
        joint_names = ["Base", "MCP", "PIP", "DIP"]
        for i, (x, y) in enumerate(keypoints[1:], 1):
            r = max(3, width//2 - 1)
            
            # Círculo externo (glow)
            self.create_oval(x-r-2, y-r-2, x+r+2, y+r+2,
                           fill="", outline=COLORS["accent_blue"],
                           width=1, dash=(2, 4))
            
            # Articulación
            self.create_oval(x-r, y-r, x+r, y+r,
                           fill=COLORS["joint_color"],
                           outline=COLORS["bg_dark"], width=1)
        
        # Punta del dedo
        if keypoints:
            tx, ty = keypoints[-1]
            r = width // 2
            self.create_oval(tx-r, ty-r, tx+r, ty+r,
                           fill=COLORS["skin_dark"],
                           outline=COLORS["border"], width=1)
    
    def _draw_labels(self):
        """Etiquetas de dedos."""
        label_positions = {
            FingerName.THUMB:  (30,  195),
            FingerName.INDEX:  (90,   95),
            FingerName.MIDDLE: (155,  85),
            FingerName.RING:   (215,  90),
            FingerName.LITTLE: (262, 105),
        }
        
        for finger_name, (lx, ly) in label_positions.items():
            finger = self.hand.fingers[finger_name]
            grip_pct = int(finger.joints.grip_level * 100)
            label = f"{finger_name.value[0]}"
            
            sx = lx*self.SCALE + self.OFFSET_X
            sy = ly*self.SCALE + self.OFFSET_Y - 15
            
            color = COLORS["accent_green"] if grip_pct > 50 else COLORS["text_secondary"]
            self.create_text(sx, sy, text=label, fill=color,
                           font=("Courier", 7, "bold"))
    
    def _draw_grip_info(self):
        """Indicador de patrón de agarre actual."""
        w = int(self.cget("width"))
        grip_pct = self.hand.get_grip_percentage()
        pattern = self.hand.current_grip.value
        
        # Barra de agarre
        bar_x = 10
        bar_y = int(self.cget("height")) - 25
        bar_w = w - 20
        
        self.create_rectangle(bar_x, bar_y, bar_x+bar_w, bar_y+10,
                             fill=COLORS["bg_widget"], outline=COLORS["border"])
        
        fill_w = int(bar_w * grip_pct / 100)
        if fill_w > 0:
            color = COLORS["accent_green"] if grip_pct < 70 else COLORS["accent_orange"]
            self.create_rectangle(bar_x, bar_y, bar_x+fill_w, bar_y+10,
                                 fill=color, outline="")
        
        self.create_text(bar_x + bar_w//2, bar_y-8,
                        text=f"{pattern}  |  Agarre: {grip_pct:.0f}%",
                        fill=COLORS["text_secondary"], font=("Courier", 8))


class EMGPanel(tk.Frame):
    """Panel de visualización de señales EMG."""
    
    HISTORY_LEN = 60
    
    def __init__(self, parent, controller: ProthesisController, **kwargs):
        super().__init__(parent, bg=COLORS["bg_panel"], **kwargs)
        self.controller = controller
        self._canvases: Dict[MuscleGroup, tk.Canvas] = {}
        self._vars: Dict[MuscleGroup, tk.DoubleVar] = {}
        self._setup_ui()
    
    def _setup_ui(self):
        title = tk.Label(self, text="◈ SEÑALES EMG", bg=COLORS["bg_panel"],
                        fg=COLORS["accent_blue"], font=("Courier", 9, "bold"))
        title.pack(pady=(8,4), padx=8, anchor="w")
        
        muscle_labels = {
            MuscleGroup.FLEXOR_FINGERS:  "Flex. Dedos",
            MuscleGroup.EXTENSOR_FINGERS:"Ext. Dedos",
            MuscleGroup.FLEXOR_THUMB:    "Flex. Pulgar",
            MuscleGroup.ABDUCTOR_THUMB:  "Abd. Pulgar",
            MuscleGroup.LATERAL_PINCH:   "Pinza Lat.",
        }
        
        for muscle, label in muscle_labels.items():
            row = tk.Frame(self, bg=COLORS["bg_panel"])
            row.pack(fill="x", padx=8, pady=2)
            
            tk.Label(row, text=label, bg=COLORS["bg_panel"],
                    fg=COLORS["text_secondary"], font=("Courier", 7),
                    width=12, anchor="w").pack(side="left")
            
            # Canvas para waveform
            c = tk.Canvas(row, width=100, height=20,
                         bg=COLORS["bg_widget"],
                         highlightthickness=1,
                         highlightbackground=COLORS["border"])
            c.pack(side="left", padx=4)
            self._canvases[muscle] = c
            
            # Slider de activación (para simulación EMG)
            var = tk.DoubleVar(value=0.0)
            self._vars[muscle] = var
            
            slider = ttk.Scale(row, from_=0.0, to=1.0, variable=var,
                              orient="horizontal", length=80,
                              command=lambda v, m=muscle: 
                                  self.controller.set_emg_muscle(m, float(v)))
            slider.pack(side="left", padx=2)
            
            # Indicador numérico
            lbl = tk.Label(row, text="0.00", bg=COLORS["bg_panel"],
                          fg=COLORS["text_muted"], font=("Courier", 7), width=4)
            lbl.pack(side="left")
            
            # Guardar referencia
            var.trace_add("write", lambda *args, l=lbl, v=var: 
                         l.config(text=f"{v.get():.2f}",
                                 fg=COLORS["accent_green"] if v.get() > 0.15 
                                    else COLORS["text_muted"]))
    
    def update_display(self):
        """Actualiza visualización de waveforms."""
        for muscle, canvas in self._canvases.items():
            history = self.controller.sensors.get_signal_history(muscle, 
                                                                   n_samples=self.HISTORY_LEN)
            self._draw_waveform(canvas, history)
    
    def _draw_waveform(self, canvas: tk.Canvas, values: List[float]):
        canvas.delete("all")
        w, h = 100, 20
        
        canvas.create_rectangle(0, 0, w, h, fill=COLORS["bg_widget"], outline="")
        
        if not values:
            return
        
        # Línea base
        canvas.create_line(0, h//2, w, h//2, fill=COLORS["border"], width=1)
        
        # Waveform
        step = w / max(1, len(values) - 1)
        points = []
        for i, v in enumerate(values):
            x = i * step
            y = h - (v * (h - 4) + 2)
            points.extend([x, y])
        
        if len(points) >= 4:
            color = COLORS["accent_green"]
            # Detectar si está activo
            if values[-1] > 0.15:
                color = COLORS["accent_orange"]
            
            canvas.create_line(points, fill=color, width=1, smooth=True)
        
        # Valor actual como barra vertical al final
        last_val = values[-1] if values else 0
        bar_h = int(last_val * h)
        if bar_h > 0:
            canvas.create_rectangle(w-4, h-bar_h, w, h,
                                   fill=COLORS["accent_green"], outline="")


class GripPatternPanel(tk.Frame):
    """Panel de selección de patrones de agarre."""
    
    PATTERNS_GRID = [
        [GripPattern.OPEN,          GripPattern.POWER_GRIP,  GripPattern.PINCH_TIP],
        [GripPattern.PINCH_LATERAL, GripPattern.TRIPOD,      GripPattern.HOOK],
        [GripPattern.POINT,         GripPattern.THUMB_UP,    GripPattern.OK_SIGN],
        [GripPattern.PEACE,         None,                     None],
    ]
    
    PATTERN_ICONS = {
        GripPattern.OPEN:          "✋",
        GripPattern.POWER_GRIP:    "✊",
        GripPattern.PINCH_TIP:     "🤌",
        GripPattern.PINCH_LATERAL: "👌",
        GripPattern.TRIPOD:        "🖖",
        GripPattern.HOOK:          "🤙",
        GripPattern.POINT:         "👆",
        GripPattern.THUMB_UP:      "👍",
        GripPattern.OK_SIGN:       "👌",
        GripPattern.PEACE:         "✌️",
    }
    
    def __init__(self, parent, controller: ProthesisController, **kwargs):
        super().__init__(parent, bg=COLORS["bg_panel"], **kwargs)
        self.controller = controller
        self._force_var = tk.DoubleVar(value=0.8)
        self._active_btn: Optional[tk.Button] = None
        self._setup_ui()
    
    def _setup_ui(self):
        title = tk.Label(self, text="◈ PATRONES DE AGARRE", bg=COLORS["bg_panel"],
                        fg=COLORS["accent_blue"], font=("Courier", 9, "bold"))
        title.pack(pady=(8,4), padx=8, anchor="w")
        
        grid_frame = tk.Frame(self, bg=COLORS["bg_panel"])
        grid_frame.pack(padx=8, pady=4)
        
        self._buttons: Dict[GripPattern, tk.Button] = {}
        
        for row_i, row in enumerate(self.PATTERNS_GRID):
            for col_i, pattern in enumerate(row):
                if pattern is None:
                    continue
                
                icon = self.PATTERN_ICONS.get(pattern, "◇")
                short_name = pattern.value.split()[-1][:8]
                btn_text = f"{icon}\n{short_name}"
                
                btn = tk.Button(
                    grid_frame,
                    text=btn_text,
                    width=8, height=3,
                    bg=COLORS["bg_widget"],
                    fg=COLORS["text_primary"],
                    activebackground=COLORS["accent_blue"],
                    activeforeground=COLORS["bg_dark"],
                    relief="flat",
                    font=("Arial", 8),
                    bd=0,
                    highlightthickness=1,
                    highlightbackground=COLORS["border"],
                    cursor="hand2",
                    command=lambda p=pattern: self._apply_pattern(p)
                )
                btn.grid(row=row_i, column=col_i, padx=3, pady=3, sticky="nsew")
                self._buttons[pattern] = btn
        
        # Control de fuerza
        force_frame = tk.Frame(self, bg=COLORS["bg_panel"])
        force_frame.pack(fill="x", padx=8, pady=(8,4))
        
        tk.Label(force_frame, text="Fuerza:", bg=COLORS["bg_panel"],
                fg=COLORS["text_secondary"], font=("Courier", 8)).pack(side="left")
        
        ttk.Scale(force_frame, from_=0.1, to=1.0, variable=self._force_var,
                 orient="horizontal", length=120).pack(side="left", padx=6)
        
        self._force_label = tk.Label(force_frame, text="80%", bg=COLORS["bg_panel"],
                                    fg=COLORS["accent_yellow"], font=("Courier", 8))
        self._force_label.pack(side="left")
        
        self._force_var.trace_add("write", self._update_force_label)
    
    def _apply_pattern(self, pattern: GripPattern):
        """Aplica patrón y actualiza botones activos."""
        force = self._force_var.get()
        self.controller.manual_grip(pattern, force)
        
        # Resaltar botón activo
        for p, btn in self._buttons.items():
            if p == pattern:
                btn.config(bg=COLORS["accent_green"], fg=COLORS["bg_dark"])
            else:
                btn.config(bg=COLORS["bg_widget"], fg=COLORS["text_primary"])
    
    def _update_force_label(self, *args):
        pct = int(self._force_var.get() * 100)
        self._force_label.config(text=f"{pct}%")


class FingerControlPanel(tk.Frame):
    """Panel de control individual de dedos."""
    
    def __init__(self, parent, controller: ProthesisController, **kwargs):
        super().__init__(parent, bg=COLORS["bg_panel"], **kwargs)
        self.controller = controller
        self._vars: Dict[FingerName, tk.DoubleVar] = {}
        self._setup_ui()
    
    def _setup_ui(self):
        title = tk.Label(self, text="◈ CONTROL INDIVIDUAL", bg=COLORS["bg_panel"],
                        fg=COLORS["accent_blue"], font=("Courier", 9, "bold"))
        title.pack(pady=(8,4), padx=8, anchor="w")
        
        for finger in FingerName:
            row = tk.Frame(self, bg=COLORS["bg_panel"])
            row.pack(fill="x", padx=8, pady=2)
            
            var = tk.DoubleVar(value=0.0)
            self._vars[finger] = var
            
            tk.Label(row, text=f"{finger.value:8}", bg=COLORS["bg_panel"],
                    fg=COLORS["text_secondary"], font=("Courier", 8),
                    width=9, anchor="w").pack(side="left")
            
            slider = ttk.Scale(row, from_=0.0, to=1.0, variable=var,
                              orient="horizontal", length=120,
                              command=lambda v, f=finger: 
                                  self.controller.manual_set_finger(f, float(v)))
            slider.pack(side="left", padx=4)
            
            # Indicador
            lbl = tk.Label(row, text="  0%", bg=COLORS["bg_panel"],
                          fg=COLORS["text_muted"], font=("Courier", 7), width=5)
            lbl.pack(side="left")
            var.trace_add("write", lambda *a, l=lbl, v=var:
                         l.config(text=f"{int(v.get()*100):3d}%",
                                 fg=COLORS["accent_green"] if v.get() > 0.1
                                    else COLORS["text_muted"]))
        
        # Muñeca
        sep = tk.Frame(self, bg=COLORS["border"], height=1)
        sep.pack(fill="x", padx=8, pady=4)
        
        wrist_row = tk.Frame(self, bg=COLORS["bg_panel"])
        wrist_row.pack(fill="x", padx=8, pady=2)
        
        self._wrist_var = tk.DoubleVar(value=0.0)
        tk.Label(wrist_row, text="Muñeca:", bg=COLORS["bg_panel"],
                fg=COLORS["accent_yellow"], font=("Courier", 8),
                width=9, anchor="w").pack(side="left")
        
        ttk.Scale(wrist_row, from_=-45, to=45, variable=self._wrist_var,
                 orient="horizontal", length=120,
                 command=lambda v: self.controller.set_wrist(float(v))).pack(side="left", padx=4)
        
        wrist_lbl = tk.Label(wrist_row, text=" 0°", bg=COLORS["bg_panel"],
                            fg=COLORS["accent_yellow"], font=("Courier", 7), width=5)
        wrist_lbl.pack(side="left")
        self._wrist_var.trace_add("write", lambda *a: wrist_lbl.config(
            text=f"{int(self._wrist_var.get()):+3d}°"))
    
    def sync_from_model(self):
        """Sincroniza sliders con el modelo actual (modo auto)."""
        for finger, var in self._vars.items():
            level = self.controller.hand.fingers[finger].joints.grip_level
            var.set(level)


class TelemetryPanel(tk.Frame):
    """Panel de telemetría y estadísticas."""
    
    def __init__(self, parent, controller: ProthesisController, **kwargs):
        super().__init__(parent, bg=COLORS["bg_panel"], **kwargs)
        self.controller = controller
        self._labels: Dict[str, tk.Label] = {}
        self._setup_ui()
    
    def _setup_ui(self):
        title = tk.Label(self, text="◈ TELEMETRÍA", bg=COLORS["bg_panel"],
                        fg=COLORS["accent_blue"], font=("Courier", 9, "bold"))
        title.pack(pady=(8,4), padx=8, anchor="w")
        
        fields = [
            ("Modo:", "mode"),
            ("Patrón:", "grip_pattern"),
            ("Agarre:", "grip_pct"),
            ("Muñeca:", "wrist_angle"),
            ("Tiempo sesión:", "session_time"),
            ("Comandos:", "command_count"),
        ]
        
        for label_text, key in fields:
            row = tk.Frame(self, bg=COLORS["bg_panel"])
            row.pack(fill="x", padx=8, pady=1)
            
            tk.Label(row, text=label_text, bg=COLORS["bg_panel"],
                    fg=COLORS["text_secondary"], font=("Courier", 7),
                    width=14, anchor="w").pack(side="left")
            
            lbl = tk.Label(row, text="—", bg=COLORS["bg_panel"],
                          fg=COLORS["text_primary"], font=("Courier", 7),
                          anchor="w")
            lbl.pack(side="left")
            self._labels[key] = lbl
        
        # Fatiga
        sep = tk.Frame(self, bg=COLORS["border"], height=1)
        sep.pack(fill="x", padx=8, pady=4)
        
        tk.Label(self, text="FATIGA MUSCULAR", bg=COLORS["bg_panel"],
                fg=COLORS["text_muted"], font=("Courier", 7, "bold")).pack(padx=8, anchor="w")
        
        self._fatigue_bars: Dict[str, tk.Canvas] = {}
        muscle_short = {
            "flexor_dedos": "Flex.Ded",
            "extensor_dedos": "Ext.Ded",
            "flexor_pulgar": "Flex.Pul",
            "abductor_pulgar": "Abd.Pul",
            "pinza_lateral": "PinzaLat",
        }
        
        for m_key, m_label in muscle_short.items():
            row = tk.Frame(self, bg=COLORS["bg_panel"])
            row.pack(fill="x", padx=8, pady=1)
            
            tk.Label(row, text=m_label, bg=COLORS["bg_panel"],
                    fg=COLORS["text_muted"], font=("Courier", 6),
                    width=9, anchor="w").pack(side="left")
            
            c = tk.Canvas(row, width=80, height=8,
                         bg=COLORS["bg_widget"], highlightthickness=0)
            c.pack(side="left", padx=2)
            self._fatigue_bars[m_key] = c
    
    def update(self, telemetry: dict):
        """Actualiza panel con datos de telemetría."""
        session_s = telemetry.get("session_time", 0)
        m, s = divmod(int(session_s), 60)
        
        updates = {
            "mode": telemetry.get("mode", "—"),
            "grip_pattern": telemetry.get("grip_pattern", "—"),
            "grip_pct": f"{telemetry.get('grip_pct', 0):.0f}%",
            "wrist_angle": f"{telemetry.get('wrist_angle', 0):+.0f}°",
            "session_time": f"{m:02d}:{s:02d}",
            "command_count": str(telemetry.get("command_count", 0)),
        }
        
        for key, value in updates.items():
            if key in self._labels:
                self._labels[key].config(text=value)
        
        # Actualizar barras de fatiga
        fatigue = telemetry.get("fatigue", {})
        for m_key, canvas in self._fatigue_bars.items():
            level = fatigue.get(m_key, 0)
            canvas.delete("all")
            canvas.create_rectangle(0, 0, 80, 8, fill=COLORS["bg_widget"], outline="")
            
            if level > 0:
                w = int(80 * level)
                if level < 0.4:
                    color = COLORS["fatigue_low"]
                elif level < 0.7:
                    color = COLORS["fatigue_mid"]
                else:
                    color = COLORS["fatigue_high"]
                canvas.create_rectangle(0, 0, w, 8, fill=color, outline="")


class LogPanel(tk.Frame):
    """Panel de log de eventos del sistema."""
    
    def __init__(self, parent, controller: ProthesisController, **kwargs):
        super().__init__(parent, bg=COLORS["bg_panel"], **kwargs)
        self.controller = controller
        self._setup_ui()
    
    def _setup_ui(self):
        title = tk.Label(self, text="◈ LOG DEL SISTEMA", bg=COLORS["bg_panel"],
                        fg=COLORS["accent_blue"], font=("Courier", 9, "bold"))
        title.pack(pady=(8,2), padx=8, anchor="w")
        
        self._text = tk.Text(
            self,
            height=6,
            bg=COLORS["bg_dark"],
            fg=COLORS["accent_green"],
            font=("Courier", 7),
            relief="flat",
            state="disabled",
            insertbackground=COLORS["accent_green"],
            highlightthickness=1,
            highlightbackground=COLORS["border"]
        )
        self._text.pack(fill="both", expand=True, padx=8, pady=(0, 8))
    
    def update(self, log_entries: List[str]):
        self._text.config(state="normal")
        self._text.delete("1.0", "end")
        for entry in log_entries[-8:]:
            self._text.insert("end", entry + "\n")
        self._text.config(state="disabled")
        self._text.see("end")


class ProthesisApp:
    """
    Aplicación principal - integra todos los componentes de la GUI.
    """
    
    TITLE = "PRÓTESIS DE MANO — SIMULACIÓN v2.0"
    UPDATE_MS = 40  # ~25 FPS para la GUI
    
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(self.TITLE)
        self.root.configure(bg=COLORS["bg_dark"])
        self.root.resizable(False, False)
        
        # Controlador del sistema
        self.controller = ProthesisController()
        self.controller.on_update = self._schedule_gui_update
        
        self._gui_update_pending = False
        self._setup_styles()
        self._build_layout()
        
        # Iniciar controlador
        self.controller.start()
        
        # Bucle de actualización GUI
        self._update_loop()
        
        # Protocolo de cierre
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        
        # Estado de modo de control
        self._mode_var = tk.StringVar(value=ControlMode.MANUAL.value)
    
    def _setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")
        
        style.configure("TScale",
                        background=COLORS["bg_panel"],
                        troughcolor=COLORS["bg_widget"],
                        sliderthickness=12,
                        sliderrelief="flat")
        
        style.configure("TNotebook",
                        background=COLORS["bg_dark"],
                        tabmargins=[2, 0, 2, 0])
        
        style.configure("TNotebook.Tab",
                        background=COLORS["bg_widget"],
                        foreground=COLORS["text_secondary"],
                        font=("Courier", 8, "bold"),
                        padding=[8, 4])
        
        style.map("TNotebook.Tab",
                 background=[("selected", COLORS["bg_panel"])],
                 foreground=[("selected", COLORS["accent_blue"])])
    
    def _build_layout(self):
        """Construye el layout principal de la aplicación."""
        
        # ── Header ──────────────────────────────────────────────────────
        header = tk.Frame(self.root, bg=COLORS["bg_dark"], height=50)
        header.pack(fill="x", padx=0, pady=0)
        header.pack_propagate(False)
        
        tk.Label(header,
                text="⬡ PRÓTESIS DE MANO · SIMULACIÓN · PROTOTIPO FUNCIONAL",
                bg=COLORS["bg_dark"],
                fg=COLORS["accent_green"],
                font=("Courier", 11, "bold")).pack(side="left", padx=16, pady=12)
        
        # Status indicator
        self._status_lbl = tk.Label(header, text="● ACTIVO",
                                   bg=COLORS["bg_dark"],
                                   fg=COLORS["accent_green"],
                                   font=("Courier", 8, "bold"))
        self._status_lbl.pack(side="right", padx=16)
        
        # Separador
        tk.Frame(self.root, bg=COLORS["accent_green"], height=1).pack(fill="x")
        
        # ── Contenido principal ──────────────────────────────────────────
        main_frame = tk.Frame(self.root, bg=COLORS["bg_dark"])
        main_frame.pack(fill="both", expand=True, padx=0, pady=0)
        
        # Columna izquierda: Canvas de la mano
        left_col = tk.Frame(main_frame, bg=COLORS["bg_dark"])
        left_col.pack(side="left", fill="y", padx=8, pady=8)
        
        # Canvas de la mano
        self.hand_canvas = HandCanvas(
            left_col,
            self.controller.hand,
            width=560, height=520
        )
        self.hand_canvas.pack()
        
        # Controles de modo
        mode_frame = tk.Frame(left_col, bg=COLORS["bg_panel"],
                             relief="flat", bd=0)
        mode_frame.pack(fill="x", pady=(8,0))
        
        tk.Label(mode_frame, text="MODO DE CONTROL:", bg=COLORS["bg_panel"],
                fg=COLORS["text_secondary"], font=("Courier", 8, "bold")).pack(
                    side="left", padx=8, pady=6)
        
        for mode in ControlMode:
            btn = tk.Button(
                mode_frame,
                text=mode.value,
                bg=COLORS["bg_widget"],
                fg=COLORS["text_secondary"],
                activebackground=COLORS["accent_blue"],
                activeforeground=COLORS["bg_dark"],
                font=("Courier", 7, "bold"),
                relief="flat",
                bd=0,
                padx=8, pady=4,
                cursor="hand2",
                command=lambda m=mode: self._set_mode(m)
            )
            btn.pack(side="left", padx=3, pady=4)
            # Guardar referencia para resaltar activo
            if not hasattr(self, '_mode_buttons'):
                self._mode_buttons = {}
            self._mode_buttons[mode] = btn
        
        self._highlight_mode_button(ControlMode.MANUAL)
        
        # Columna derecha: Paneles de control
        right_col = tk.Frame(main_frame, bg=COLORS["bg_dark"])
        right_col.pack(side="left", fill="both", expand=True, padx=0, pady=8)
        
        # Notebook con tabs
        notebook = ttk.Notebook(right_col)
        notebook.pack(fill="both", expand=True, padx=8)
        
        # Tab 1: Patrones
        tab_patterns = tk.Frame(notebook, bg=COLORS["bg_panel"])
        notebook.add(tab_patterns, text=" PATRONES ")
        
        self.grip_panel = GripPatternPanel(tab_patterns, self.controller)
        self.grip_panel.pack(fill="both", expand=True)
        
        # Tab 2: Dedos
        tab_fingers = tk.Frame(notebook, bg=COLORS["bg_panel"])
        notebook.add(tab_fingers, text=" DEDOS ")
        
        self.finger_panel = FingerControlPanel(tab_fingers, self.controller)
        self.finger_panel.pack(fill="both", expand=True)
        
        # Tab 3: EMG
        tab_emg = tk.Frame(notebook, bg=COLORS["bg_panel"])
        notebook.add(tab_emg, text=" EMG ")
        
        self.emg_panel = EMGPanel(tab_emg, self.controller)
        self.emg_panel.pack(fill="both", expand=True)
        
        # Telemetría (siempre visible)
        self.telemetry_panel = TelemetryPanel(right_col, self.controller)
        self.telemetry_panel.pack(fill="x", padx=8, pady=(4,0))
        
        # Log
        self.log_panel = LogPanel(right_col, self.controller)
        self.log_panel.pack(fill="x", padx=8, pady=(4,8))
        
        # Botones de acción
        action_frame = tk.Frame(right_col, bg=COLORS["bg_dark"])
        action_frame.pack(fill="x", padx=8, pady=(0,4))
        
        for text, cmd, color in [
            ("⟳ Resetear", self.controller.reset_session, COLORS["accent_blue"]),
            ("◉ Fatiga Reset", self.controller.sensors.reset_fatigue, COLORS["accent_yellow"]),
        ]:
            tk.Button(
                action_frame, text=text,
                bg=COLORS["bg_widget"], fg=color,
                activebackground=color, activeforeground=COLORS["bg_dark"],
                font=("Courier", 8, "bold"),
                relief="flat", bd=0, padx=10, pady=4,
                cursor="hand2", command=cmd
            ).pack(side="left", padx=3)
    
    def _set_mode(self, mode: ControlMode):
        """Cambia el modo de control."""
        self.controller.set_mode(mode)
        self._highlight_mode_button(mode)
        
        # En modo manual, habilitar paneles de control
        manual = (mode == ControlMode.MANUAL)
        # (Los paneles siempre son accesibles, el controlador filtra)
    
    def _highlight_mode_button(self, active_mode: ControlMode):
        for mode, btn in self._mode_buttons.items():
            if mode == active_mode:
                btn.config(bg=COLORS["accent_blue"], fg=COLORS["bg_dark"])
            else:
                btn.config(bg=COLORS["bg_widget"], fg=COLORS["text_secondary"])
    
    def _schedule_gui_update(self):
        """Callback del controlador - programa actualización de GUI."""
        if not self._gui_update_pending:
            self._gui_update_pending = True
    
    def _update_loop(self):
        """Bucle de actualización de la GUI."""
        if self._gui_update_pending:
            self._do_update()
            self._gui_update_pending = False
        
        self.root.after(self.UPDATE_MS, self._update_loop)
    
    def _do_update(self):
        """Actualiza todos los elementos de la GUI."""
        # Renderizar mano
        self.hand_canvas.render()
        
        # Actualizar señales EMG
        self.emg_panel.update_display()
        
        # Sincronizar sliders de dedos en modo automático
        if self.controller.state.mode != ControlMode.MANUAL:
            self.finger_panel.sync_from_model()
        
        # Telemetría
        telemetry = self.controller.get_telemetry()
        self.telemetry_panel.update(telemetry)
        
        # Log
        self.log_panel.update(self.controller.get_log())
        
        # Demo description
        if self.controller.state.mode == ControlMode.AUTO_DEMO:
            self._status_lbl.config(
                text=f"▶ {self.controller.demo.current_description}",
                fg=COLORS["accent_yellow"]
            )
        else:
            self._status_lbl.config(text="● ACTIVO", fg=COLORS["accent_green"])
    
    def _on_close(self):
        """Cierre limpio del sistema."""
        self.controller.stop()
        self.root.destroy()
