"""
╔══════════════════════════════════════════════════════════════╗
║         SIMULACIÓN DE PRÓTESIS DE MANO - PROTOTIPO          ║
║         Sistema de Control Mioeléctrico Inteligente          ║
╚══════════════════════════════════════════════════════════════╝

Arquitectura del sistema:
  - sensors.py      → Simulación de sensores EMG musculares
  - hand_model.py   → Modelo cinemático de la mano
  - controller.py   → Controlador de señales y patrones
  - gui.py          → Interfaz gráfica con visualización
  - main.py         → Punto de entrada principal
"""

import tkinter as tk
import sys
import os

# Añadir directorio actual al path
sys.path.insert(0, os.path.dirname(__file__))

from gui import ProthesisApp


def main():
    root = tk.Tk()
    app = ProthesisApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
