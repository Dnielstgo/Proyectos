"""
sensors.py - Módulo de Simulación de Sensores EMG
==================================================
Simula señales electromiográficas (EMG) de músculos del antebrazo.
En un sistema real, estas señales vendrían de electrodos de superficie.

Músculos simulados:
  - Flexor digitorum superficialis (cierre de dedos)
  - Extensor digitorum (apertura de dedos)
  - Flexor pollicis longus (pulgar)
  - Abductor pollicis brevis (abducción pulgar)
"""

import random
import math
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Dict


class MuscleGroup(Enum):
    FLEXOR_FINGERS  = "flexor_dedos"
    EXTENSOR_FINGERS = "extensor_dedos"
    FLEXOR_THUMB    = "flexor_pulgar"
    ABDUCTOR_THUMB  = "abductor_pulgar"
    LATERAL_PINCH   = "pinza_lateral"


@dataclass
class EMGSignal:
    """Representa una señal EMG en un instante de tiempo."""
    timestamp: float
    muscle: MuscleGroup
    raw_value: float        # µV (microvoltios) - rango 0-1000 µV
    filtered_value: float   # Señal filtrada
    activation_level: float # 0.0 - 1.0 (normalizado)
    
    @property
    def is_active(self) -> bool:
        return self.activation_level > 0.15  # Umbral de activación


class EMGFilter:
    """
    Filtro digital para señales EMG.
    Implementa filtro pasa-banda + rectificación + suavizado.
    """
    
    def __init__(self, window_size: int = 10):
        self.window_size = window_size
        self.buffer: List[float] = []
        self.noise_floor = 5.0  # µV de ruido de fondo
    
    def process(self, raw_signal: float) -> float:
        """
        Pipeline de procesamiento:
        1. Eliminar línea base (DC offset)
        2. Rectificación de onda completa
        3. Suavizado mediante media móvil (RMS envolvente)
        """
        # Añadir ruido de fondo realista
        noisy = raw_signal + random.gauss(0, self.noise_floor)
        
        # Rectificación
        rectified = abs(noisy)
        
        # Buffer circular para media móvil
        self.buffer.append(rectified)
        if len(self.buffer) > self.window_size:
            self.buffer.pop(0)
        
        # RMS (Root Mean Square) - más realista que media simple
        if self.buffer:
            rms = math.sqrt(sum(x**2 for x in self.buffer) / len(self.buffer))
        else:
            rms = 0.0
            
        return rms


class MuscleSensor:
    """
    Sensor EMG individual para un grupo muscular.
    Simula el comportamiento electromiográfico con fatiga y ruido.
    """
    
    MAX_AMPLITUDE = 1000.0  # µV máximo
    FATIGUE_RATE  = 0.001   # Tasa de fatiga por actualización
    RECOVERY_RATE = 0.003   # Tasa de recuperación en reposo
    
    def __init__(self, muscle: MuscleGroup):
        self.muscle = muscle
        self.target_activation = 0.0   # Activación objetivo (comando)
        self.current_activation = 0.0  # Activación real (con inercia)
        self.fatigue_level = 0.0       # 0 = sin fatiga, 1 = fatiga total
        self.filter = EMGFilter(window_size=8)
        self._time = 0.0
        self._inertia = 0.12           # Factor de suavizado temporal
        
    def set_activation(self, level: float):
        """Establece nivel de activación objetivo (0.0 - 1.0)."""
        self.target_activation = max(0.0, min(1.0, level))
    
    def update(self, dt: float = 0.02) -> EMGSignal:
        """
        Actualiza el estado del sensor y genera señal EMG.
        
        Returns:
            EMGSignal con los valores actuales
        """
        self._time += dt
        
        # Suavizado con inercia muscular (los músculos no son instantáneos)
        diff = self.target_activation - self.current_activation
        self.current_activation += diff * (1 - self.inertia_factor)
        
        # Modelo de fatiga muscular
        if self.current_activation > 0.1:
            self.fatigue_level = min(1.0, 
                self.fatigue_level + self.FATIGUE_RATE * self.current_activation)
        else:
            self.fatigue_level = max(0.0, 
                self.fatigue_level - self.RECOVERY_RATE)
        
        # Activación efectiva (reducida por fatiga)
        effective_activation = self.current_activation * (1 - 0.4 * self.fatigue_level)
        
        # Generar señal EMG sintética realista
        # La amplitud EMG ≈ nivel de activación × amplitud máxima
        raw_amplitude = effective_activation * self.MAX_AMPLITUDE
        
        # Añadir características de señal EMG real:
        # - Componente de alta frecuencia (tremor motor)
        # - Variabilidad estocástica de unidades motoras
        motor_units_noise = random.gauss(0, raw_amplitude * 0.15)
        tremor = math.sin(2 * math.pi * 12 * self._time) * raw_amplitude * 0.05
        
        raw_signal = raw_amplitude + motor_units_noise + tremor
        filtered = self.filter.process(raw_signal)
        
        # Normalizar activación filtrada
        activation_norm = min(1.0, filtered / self.MAX_AMPLITUDE)
        
        return EMGSignal(
            timestamp=self._time,
            muscle=self.muscle,
            raw_value=max(0, raw_signal),
            filtered_value=filtered,
            activation_level=activation_norm
        )
    
    @property
    def inertia_factor(self) -> float:
        """Factor de inercia variable según fatiga."""
        return self._inertia + 0.05 * self.fatigue_level


class EMGSensorArray:
    """
    Array de sensores EMG para control de la prótesis.
    Gestiona múltiples canales y detección de patrones.
    """
    
    def __init__(self):
        self.sensors: Dict[MuscleGroup, MuscleSensor] = {
            muscle: MuscleSensor(muscle) 
            for muscle in MuscleGroup
        }
        self.signal_history: Dict[MuscleGroup, List[EMGSignal]] = {
            muscle: [] for muscle in MuscleGroup
        }
        self.max_history = 100  # Muestras a conservar
        
    def set_muscle_activation(self, muscle: MuscleGroup, level: float):
        """Activa un músculo a un nivel dado."""
        if muscle in self.sensors:
            self.sensors[muscle].set_activation(level)
    
    def update_all(self) -> Dict[MuscleGroup, EMGSignal]:
        """Actualiza todos los sensores y retorna señales actuales."""
        signals = {}
        for muscle, sensor in self.sensors.items():
            signal = sensor.update()
            signals[muscle] = signal
            
            # Guardar historial
            self.signal_history[muscle].append(signal)
            if len(self.signal_history[muscle]) > self.max_history:
                self.signal_history[muscle].pop(0)
        
        return signals
    
    def get_fatigue_levels(self) -> Dict[MuscleGroup, float]:
        """Retorna niveles de fatiga de todos los músculos."""
        return {
            muscle: sensor.fatigue_level 
            for muscle, sensor in self.sensors.items()
        }
    
    def reset_fatigue(self):
        """Resetea niveles de fatiga (simulando descanso)."""
        for sensor in self.sensors.values():
            sensor.fatigue_level = 0.0
    
    def get_signal_history(self, muscle: MuscleGroup, n_samples: int = 50) -> List[float]:
        """Retorna historial de activación para visualización."""
        history = self.signal_history.get(muscle, [])
        values = [s.activation_level for s in history[-n_samples:]]
        # Rellenar si no hay suficientes muestras
        while len(values) < n_samples:
            values.insert(0, 0.0)
        return values
