"""
hand_model.py - Modelo Cinemático de la Mano Protésica
=======================================================
Implementa el modelo cinemático de una mano con 5 dedos.
Cada dedo tiene articulaciones MCP, PIP y DIP.

Nomenclatura anatómica:
  MCP = Metacarpofalángica (nudillo principal)
  PIP = Interfalángica proximal (articulación media)
  DIP = Interfalángica distal (articulación distal)
  IP  = Interfalángica (solo pulgar)

Rangos de movimiento (ROM) reales:
  Dedos 2-5: MCP 0-90°, PIP 0-100°, DIP 0-70°
  Pulgar: CMC 0-50°, MCP 0-50°, IP 0-80°
"""

import math
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Tuple, Dict, Optional


class FingerName(Enum):
    THUMB  = "Pulgar"
    INDEX  = "Índice"
    MIDDLE = "Medio"
    RING   = "Anular"
    LITTLE = "Meñique"


@dataclass
class JointAngle:
    """Ángulo de una articulación con límites."""
    name: str
    value: float    # Grados actuales
    min_angle: float = 0.0
    max_angle: float = 90.0
    target: float = 0.0
    speed: float = 120.0   # °/segundo
    
    def clamp(self, angle: float) -> float:
        return max(self.min_angle, min(self.max_angle, angle))
    
    def set_target(self, angle: float):
        self.target = self.clamp(angle)
    
    def update(self, dt: float):
        """Actualiza el ángulo moviéndose hacia el objetivo."""
        diff = self.target - self.value
        max_step = self.speed * dt
        if abs(diff) <= max_step:
            self.value = self.target
        else:
            self.value += max_step * (1 if diff > 0 else -1)
    
    @property
    def normalized(self) -> float:
        """Ángulo normalizado 0.0 - 1.0."""
        range_ = self.max_angle - self.min_angle
        if range_ == 0:
            return 0.0
        return (self.value - self.min_angle) / range_


@dataclass
class FingerJoints:
    """Articulaciones de un dedo."""
    mcp: JointAngle  # Metacarpofalángica
    pip: JointAngle  # Interfalángica proximal
    dip: JointAngle  # Interfalángica distal
    
    def update(self, dt: float):
        self.mcp.update(dt)
        self.pip.update(dt)
        self.dip.update(dt)
    
    @property
    def total_flexion(self) -> float:
        """Suma total de flexión en grados."""
        return self.mcp.value + self.pip.value + self.dip.value
    
    @property
    def grip_level(self) -> float:
        """Nivel de agarre normalizado 0-1."""
        max_total = self.mcp.max_angle + self.pip.max_angle + self.dip.max_angle
        return self.total_flexion / max_total if max_total > 0 else 0


class Finger:
    """
    Modelo de un dedo con cinemática directa 2D.
    
    Segmentos:
      - Proximal  (falange proximal)
      - Medial    (falange media) 
      - Distal    (falange distal)
    """
    
    # Longitudes de falanges en mm (escala relativa)
    SEGMENT_LENGTHS = {
        FingerName.THUMB:  [0, 35, 30],       # CMC-MCP, proximal, distal
        FingerName.INDEX:  [0, 40, 25, 18],
        FingerName.MIDDLE: [0, 45, 28, 20],
        FingerName.RING:   [0, 42, 27, 19],
        FingerName.LITTLE: [0, 35, 22, 15],
    }
    
    def __init__(self, name: FingerName, base_position: Tuple[float, float], 
                 base_angle: float = -90.0):
        self.name = name
        self.base_position = base_position  # (x, y) posición base
        self.base_angle = base_angle        # Ángulo base en grados
        self.segments = self.SEGMENT_LENGTHS[name][1:]
        
        # Inicializar articulaciones según tipo de dedo
        if name == FingerName.THUMB:
            self.joints = FingerJoints(
                mcp=JointAngle("CMC-MCP", 0.0, -20.0, 50.0, speed=100.0),
                pip=JointAngle("MCP",     0.0,   0.0, 50.0, speed=110.0),
                dip=JointAngle("IP",      0.0,   0.0, 80.0, speed=120.0),
            )
        else:
            self.joints = FingerJoints(
                mcp=JointAngle("MCP", 0.0, 0.0, 85.0,  speed=120.0),
                pip=JointAngle("PIP", 0.0, 0.0, 100.0, speed=130.0),
                dip=JointAngle("DIP", 0.0, 0.0, 70.0,  speed=120.0),
            )
        
        self._abduction = 0.0  # Abducción lateral en grados
    
    def set_flexion(self, level: float, pattern: str = "natural"):
        """
        Flexiona el dedo a un nivel dado (0.0 = extendido, 1.0 = cerrado).
        
        Patrones de movimiento:
          natural - Cierre fisiológico (DIP sigue a PIP con retraso)
          power   - Agarre de fuerza (todos a la vez)
          tip     - Agarre de punta (solo PIP y DIP)
        """
        level = max(0.0, min(1.0, level))
        
        if pattern == "natural":
            # Cinemática natural: MCP lidera, luego PIP, luego DIP
            mcp_level = min(1.0, level * 1.2)
            pip_level = max(0.0, min(1.0, (level - 0.1) * 1.3))
            dip_level = max(0.0, min(1.0, (level - 0.2) * 1.4))
        elif pattern == "power":
            mcp_level = pip_level = dip_level = level
        elif pattern == "tip":
            mcp_level = level * 0.3
            pip_level = level * 0.9
            dip_level = level
        else:
            mcp_level = pip_level = dip_level = level
        
        self.joints.mcp.set_target(self.joints.mcp.max_angle * mcp_level)
        self.joints.pip.set_target(self.joints.pip.max_angle * pip_level)
        self.joints.dip.set_target(self.joints.dip.max_angle * dip_level)
    
    def set_abduction(self, angle: float):
        """Establece abducción lateral del dedo."""
        self._abduction = max(-20.0, min(20.0, angle))
    
    def update(self, dt: float):
        """Actualiza cinemática del dedo."""
        self.joints.update(dt)
    
    def get_keypoints(self, scale: float = 1.0) -> List[Tuple[float, float]]:
        """
        Calcula posiciones cartesianas de articulaciones mediante
        cinemática directa (forward kinematics).
        
        Returns:
            Lista de (x, y) para cada articulación:
            [base, MCP, PIP, DIP, punta]
        """
        points = [self.base_position]
        
        x, y = self.base_position
        # Ángulo acumulado (la base es el ángulo de inicio del dedo)
        angle_rad = math.radians(self.base_angle + self._abduction)
        
        joint_angles = [
            self.joints.mcp.value,
            self.joints.pip.value,
            self.joints.dip.value,
        ]
        
        for i, seg_len in enumerate(self.segments):
            seg_scaled = seg_len * scale
            # Añadir flexión de la articulación actual
            if i < len(joint_angles):
                angle_rad += math.radians(joint_angles[i])
            
            x += seg_scaled * math.cos(angle_rad)
            y += seg_scaled * math.sin(angle_rad)
            points.append((x, y))
        
        return points
    
    @property
    def is_fully_closed(self) -> bool:
        return self.joints.grip_level > 0.85
    
    @property
    def is_extended(self) -> bool:
        return self.joints.grip_level < 0.05


class GripPattern(Enum):
    """Patrones de agarre definidos clínicamente."""
    OPEN           = "Mano abierta"
    POWER_GRIP     = "Agarre de fuerza"
    PINCH_TIP      = "Pinza digital"
    PINCH_LATERAL  = "Pinza lateral"
    TRIPOD         = "Agarre trípode"
    HOOK           = "Agarre gancho"
    POINT          = "Dedo índice"
    THUMB_UP       = "Pulgar arriba"
    OK_SIGN        = "OK"
    PEACE          = "Paz / Victoria"


class HandModel:
    """
    Modelo completo de la mano protésica.
    
    Gestiona los 5 dedos, patrones de agarre predefinidos,
    y la cinemática general de la mano.
    """
    
    # Posiciones base de cada dedo (x relativo, y relativo)
    # Coordenadas para renderizado 2D
    FINGER_BASES = {
        FingerName.THUMB:  (60,  200),
        FingerName.INDEX:  (120, 120),
        FingerName.MIDDLE: (165, 110),
        FingerName.RING:   (210, 115),
        FingerName.LITTLE: (250, 130),
    }
    
    FINGER_BASE_ANGLES = {
        FingerName.THUMB:  -140.0,
        FingerName.INDEX:  -85.0,
        FingerName.MIDDLE: -90.0,
        FingerName.RING:   -92.0,
        FingerName.LITTLE: -95.0,
    }
    
    def __init__(self):
        self.fingers: Dict[FingerName, Finger] = {}
        
        for name in FingerName:
            self.fingers[name] = Finger(
                name=name,
                base_position=self.FINGER_BASES[name],
                base_angle=self.FINGER_BASE_ANGLES[name]
            )
        
        self.current_grip = GripPattern.OPEN
        self.grip_force = 0.0       # 0.0 - 1.0
        self.wrist_angle = 0.0      # -45 a +45 grados
        self._grip_patterns = self._define_grip_patterns()
    
    def _define_grip_patterns(self) -> Dict[GripPattern, Dict]:
        """
        Define los patrones de agarre.
        Cada patrón especifica el nivel de flexión de cada dedo (0-1).
        Formato: {FingerName: (flexion_level, pattern_type)}
        """
        O = FingerName
        return {
            GripPattern.OPEN: {
                O.THUMB: (0.0, "natural"), O.INDEX: (0.0, "natural"),
                O.MIDDLE: (0.0, "natural"), O.RING: (0.0, "natural"),
                O.LITTLE: (0.0, "natural"),
            },
            GripPattern.POWER_GRIP: {
                O.THUMB: (0.7, "natural"), O.INDEX: (0.95, "power"),
                O.MIDDLE: (0.95, "power"), O.RING: (0.90, "power"),
                O.LITTLE: (0.85, "power"),
            },
            GripPattern.PINCH_TIP: {
                O.THUMB: (0.65, "natural"), O.INDEX: (0.70, "tip"),
                O.MIDDLE: (0.15, "natural"), O.RING: (0.20, "natural"),
                O.LITTLE: (0.25, "natural"),
            },
            GripPattern.PINCH_LATERAL: {
                O.THUMB: (0.50, "natural"), O.INDEX: (0.30, "natural"),
                O.MIDDLE: (0.20, "natural"), O.RING: (0.15, "natural"),
                O.LITTLE: (0.15, "natural"),
            },
            GripPattern.TRIPOD: {
                O.THUMB: (0.60, "natural"), O.INDEX: (0.65, "tip"),
                O.MIDDLE: (0.65, "tip"), O.RING: (0.20, "natural"),
                O.LITTLE: (0.20, "natural"),
            },
            GripPattern.HOOK: {
                O.THUMB: (0.0, "natural"), O.INDEX: (0.60, "tip"),
                O.MIDDLE: (0.60, "tip"), O.RING: (0.60, "tip"),
                O.LITTLE: (0.55, "tip"),
            },
            GripPattern.POINT: {
                O.THUMB: (0.30, "natural"), O.INDEX: (0.0, "natural"),
                O.MIDDLE: (0.75, "power"), O.RING: (0.80, "power"),
                O.LITTLE: (0.75, "power"),
            },
            GripPattern.THUMB_UP: {
                O.THUMB: (0.0, "natural"), O.INDEX: (0.85, "power"),
                O.MIDDLE: (0.85, "power"), O.RING: (0.85, "power"),
                O.LITTLE: (0.80, "power"),
            },
            GripPattern.OK_SIGN: {
                O.THUMB: (0.60, "natural"), O.INDEX: (0.75, "tip"),
                O.MIDDLE: (0.0, "natural"), O.RING: (0.15, "natural"),
                O.LITTLE: (0.20, "natural"),
            },
            GripPattern.PEACE: {
                O.THUMB: (0.40, "natural"), O.INDEX: (0.0, "natural"),
                O.MIDDLE: (0.0, "natural"), O.RING: (0.80, "power"),
                O.LITTLE: (0.80, "power"),
            },
        }
    
    def apply_grip_pattern(self, pattern: GripPattern, force: float = 1.0):
        """Aplica un patrón de agarre predefinido."""
        self.current_grip = pattern
        self.grip_force = max(0.0, min(1.0, force))
        
        if pattern in self._grip_patterns:
            for finger_name, (base_level, pattern_type) in self._grip_patterns[pattern].items():
                actual_level = base_level * force if base_level > 0 else 0
                self.fingers[finger_name].set_flexion(actual_level, pattern_type)
    
    def set_finger_flexion(self, finger: FingerName, level: float):
        """Control individual de un dedo."""
        self.fingers[finger].set_flexion(level)
    
    def set_wrist(self, angle: float):
        """Establece ángulo de muñeca (-45 a +45 grados)."""
        self.wrist_angle = max(-45.0, min(45.0, angle))
    
    def update(self, dt: float):
        """Actualiza la cinemática de toda la mano."""
        for finger in self.fingers.values():
            finger.update(dt)
    
    def get_grip_percentage(self) -> float:
        """Porcentaje promedio de cierre de la mano."""
        levels = [f.joints.grip_level for f in self.fingers.values()]
        return sum(levels) / len(levels) * 100
    
    def get_finger_angles(self) -> Dict[FingerName, Dict[str, float]]:
        """Retorna todos los ángulos articulares actuales."""
        result = {}
        for name, finger in self.fingers.items():
            result[name] = {
                "mcp": finger.joints.mcp.value,
                "pip": finger.joints.pip.value,
                "dip": finger.joints.dip.value,
            }
        return result
