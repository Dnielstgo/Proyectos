# SIMULACIÓN DE PRÓTESIS DE MANO
## Prototipo Funcional en Python

---

## 📋 DESCRIPCIÓN

Sistema de simulación completo de una prótesis de mano mioeléctrica que incluye:

- **Modelo cinemático** de 5 dedos con articulaciones MCP, PIP y DIP
- **Sensores EMG** simulados con ruido realista, fatiga muscular e inercia
- **10 patrones de agarre** predefinidos clínicamente
- **4 modos de control**: Manual, EMG Directo, Reconocimiento de Patrones, Demo Automática
- **Interfaz gráfica** en tiempo real con visualización 2D de la mano
- **Telemetría** en tiempo real con monitoreo de fatiga muscular

---

## 🏗️ ARQUITECTURA

```
protesis_mano/
├── main.py          → Punto de entrada
├── sensors.py       → Simulación de sensores EMG
├── hand_model.py    → Modelo cinemático de la mano
├── controller.py    → Controlador del sistema
└── gui.py           → Interfaz gráfica (tkinter)
```

### Módulos principales:

#### `sensors.py` — Sensores EMG
- 5 canales musculares: Flexor dedos, Extensor dedos, Flexor pulgar, Abductor pulgar, Pinza lateral
- Filtro digital con rectificación + RMS (Root Mean Square)
- Modelo de fatiga muscular con recuperación
- Ruido gaussiano y tremor motor simulado

#### `hand_model.py` — Modelo Cinemático
- 5 dedos con 3 articulaciones cada uno (15 GDL total)
- Cinemática directa 2D para visualización
- 10 patrones de agarre: Fuerza, Pinza, Lateral, Trípode, Gancho, etc.
- ROM (Rango de Movimiento) anatómicamente correcto

#### `controller.py` — Controlador
- Control directo proporcional EMG
- Reconocimiento de patrones por umbral multi-canal
- Detección de co-contracción muscular
- Secuencia de demostración automática
- Hilo de control a 50 Hz

#### `gui.py` — Interfaz Gráfica
- Renderizado 2D de la mano con cinemática en tiempo real
- Panel de señales EMG con waveforms
- Control de patrones de agarre con iconos
- Sliders de control individual por dedo
- Telemetría y log del sistema

---

## 🚀 INSTALACIÓN Y USO

### Requisitos
```
Python 3.8+
tkinter (incluido en Python estándar)
```

No requiere instalación de librerías externas.

### Ejecutar
```bash
cd protesis_mano
python main.py
```

---

## 🎮 MODOS DE CONTROL

| Modo | Descripción |
|------|-------------|
| **Manual** | Control directo con sliders y botones de patrón |
| **EMG Directo** | Usa sliders de EMG para cerrar/abrir la mano |
| **Patrones EMG** | Reconoce combinaciones musculares para seleccionar agarre |
| **Demo Auto** | Cicla automáticamente por todos los patrones |

---

## 🤚 PATRONES DE AGARRE

| Patrón | Uso clínico |
|--------|-------------|
| Mano abierta | Posición de reposo |
| Agarre de fuerza | Agarrar objetos grandes/cilíndricos |
| Pinza digital | Objetos pequeños (teclas, botones) |
| Pinza lateral | Tarjetas, papeles |
| Trípode | Escribir, sostener vasos |
| Gancho | Bolsas, asas |
| Señalar | Apuntar, navegar interfaces |
| Pulgar arriba | Comunicación gestual |
| OK | Precisión |
| Paz/Victoria | Comunicación gestual |

---

## 📊 SEÑALES EMG SIMULADAS

Las señales simulan electrodos de superficie en el antebrazo:

```
Amplitud: 0 - 1000 µV (microvoltios)
Ruido de fondo: ~5 µV gaussiano
Tremor motor: 12 Hz, 5% amplitud
Fatiga: Acumulación proporcional a activación
Recuperación: 3x más rápida que acumulación
```

---

## 🔧 PARÁMETROS CONFIGURABLES (controller.py)

```python
config.activation_threshold = 0.15   # Umbral mínimo EMG
config.hysteresis = 0.05             # Anti-oscilación
config.max_grip_speed = 0.8          # Velocidad de cierre
config.sensitivity = 1.0             # Sensibilidad global
config.co_contraction_threshold = 0.4 # Umbral co-contracción
```
