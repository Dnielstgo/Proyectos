"""
controller.py - Controlador de la Prótesis
==========================================
Traduce señales EMG en comandos de movimiento para la mano.

Modos de control implementados:
  1. DIRECTO    - Señal EMG → movimiento proporcional
  2. PATRON     - Reconocimiento de gestos EMG predefinidos
  3. MANUAL     - Control por interfaz (sin EMG)
  4. AUTOMATICO - Secuencias predefinidas

El controlador implementa:
  - Umbral de activación configurable
  - Histéresis para evitar oscilaciones
  - Limitación de velocidad de cambio
  - Detección de intención de movimiento
"""

import time
import threading
from enum import Enum
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass, field

from sensors import EMGSensorArray, MuscleGroup, EMGSignal
from hand_model import HandModel, FingerName, GripPattern


class ControlMode(Enum):
    MANUAL    = "Control Manual"
    DIRECT    = "Control Directo EMG"
    PATTERN   = "Reconocimiento de Patrones"
    AUTO_DEMO = "Demostración Automática"


@dataclass
class ControlConfig:
    """Parámetros de configuración del controlador."""
    activation_threshold: float = 0.15   # Umbral mínimo de activación
    hysteresis: float = 0.05             # Banda de histéresis
    max_grip_speed: float = 0.8          # Velocidad máxima de agarre (0-1/seg)
    sensitivity: float = 1.0             # Multiplicador de sensibilidad
    proportional_control: bool = True    # Control proporcional vs umbral
    co_contraction_threshold: float = 0.4  # Umbral para co-contracción


@dataclass
class ControlState:
    """Estado actual del controlador."""
    mode: ControlMode = ControlMode.MANUAL
    current_grip: GripPattern = GripPattern.OPEN
    grip_level: float = 0.0
    wrist_position: float = 0.0
    last_command_time: float = field(default_factory=time.time)
    command_count: int = 0
    session_start: float = field(default_factory=time.time)


class DemoSequence:
    """Secuencia de demostración automática."""
    
    SEQUENCE = [
        # (patrón, fuerza, duración_segundos, descripción)
        (GripPattern.OPEN,        1.0, 1.5, "Mano abierta"),
        (GripPattern.POWER_GRIP,  0.8, 2.0, "Agarre de fuerza"),
        (GripPattern.OPEN,        1.0, 1.0, "Relajar"),
        (GripPattern.PINCH_TIP,   0.9, 2.0, "Pinza digital"),
        (GripPattern.OPEN,        1.0, 1.0, "Relajar"),
        (GripPattern.TRIPOD,      0.9, 2.0, "Agarre trípode"),
        (GripPattern.OPEN,        1.0, 1.0, "Relajar"),
        (GripPattern.POINT,       1.0, 2.0, "Señalar"),
        (GripPattern.PEACE,       1.0, 2.0, "Señal de paz"),
        (GripPattern.OK_SIGN,     1.0, 2.0, "OK"),
        (GripPattern.THUMB_UP,    1.0, 2.0, "Pulgar arriba"),
        (GripPattern.HOOK,        0.8, 2.0, "Agarre gancho"),
        (GripPattern.PINCH_LATERAL, 0.8, 2.0, "Pinza lateral"),
        (GripPattern.OPEN,        1.0, 1.5, "Mano abierta"),
    ]
    
    def __init__(self):
        self._index = 0
        self._step_start = time.time()
        self.current_description = ""
    
    def reset(self):
        self._index = 0
        self._step_start = time.time()
    
    def get_current_step(self):
        """Retorna el paso actual y avanza si corresponde."""
        if not self.SEQUENCE:
            return None
            
        current = self.SEQUENCE[self._index]
        pattern, force, duration, desc = current
        self.current_description = desc
        
        # Verificar si es momento de avanzar
        elapsed = time.time() - self._step_start
        if elapsed >= duration:
            self._index = (self._index + 1) % len(self.SEQUENCE)
            self._step_start = time.time()
        
        return pattern, force


class ProthesisController:
    """
    Controlador principal de la prótesis.
    
    Integra sensores EMG, modelo de la mano y lógica de control.
    Ejecuta en un hilo separado para control en tiempo real.
    """
    
    UPDATE_RATE = 50   # Hz (actualizaciones por segundo)
    
    def __init__(self):
        self.sensors = EMGSensorArray()
        self.hand = HandModel()
        self.config = ControlConfig()
        self.state = ControlState()
        self.demo = DemoSequence()
        
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._dt = 1.0 / self.UPDATE_RATE
        
        # Callbacks para la GUI
        self.on_update: Optional[Callable] = None
        self.on_pattern_detected: Optional[Callable] = None
        
        # Estado interno del control directo
        self._current_grip_level = 0.0
        self._grip_active = False
        
        # Log de eventos
        self.event_log: List[str] = []
        self._max_log = 50
    
    def start(self):
        """Inicia el bucle de control en hilo separado."""
        if not self._running:
            self._running = True
            self._thread = threading.Thread(target=self._control_loop, daemon=True)
            self._thread.start()
            self._log("Sistema iniciado")
    
    def stop(self):
        """Detiene el bucle de control."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=1.0)
        self._log("Sistema detenido")
    
    def _control_loop(self):
        """Bucle principal de control a tasa fija."""
        import time
        next_time = time.perf_counter()
        
        while self._running:
            # Actualizar sensores
            signals = self.sensors.update_all()
            
            # Procesar según modo de control
            if self.state.mode == ControlMode.DIRECT:
                self._process_direct_control(signals)
            elif self.state.mode == ControlMode.PATTERN:
                self._process_pattern_control(signals)
            elif self.state.mode == ControlMode.AUTO_DEMO:
                self._process_demo()
            # MANUAL: la GUI controla directamente
            
            # Actualizar modelo cinemático
            self.hand.update(self._dt)
            
            # Notificar GUI
            if self.on_update:
                self.on_update()
            
            # Control de timing preciso
            next_time += self._dt
            sleep_time = next_time - time.perf_counter()
            if sleep_time > 0:
                time.sleep(sleep_time)
    
    def _process_direct_control(self, signals: Dict[MuscleGroup, EMGSignal]):
        """
        Control directo EMG:
        - Flexor activo → cerrar mano
        - Extensor activo → abrir mano
        - Co-contracción → cambiar patrón
        """
        flexor_level = signals[MuscleGroup.FLEXOR_FINGERS].activation_level
        extensor_level = signals[MuscleGroup.EXTENSOR_FINGERS].activation_level
        thumb_level = signals[MuscleGroup.FLEXOR_THUMB].activation_level
        
        # Aplicar umbral y sensibilidad
        flex_active = flexor_level > self.config.activation_threshold
        ext_active = extensor_level > self.config.activation_threshold
        
        # Detectar co-contracción (ambos músculos activos simultáneamente)
        co_contraction = (flexor_level > self.config.co_contraction_threshold and
                         extensor_level > self.config.co_contraction_threshold)
        
        if co_contraction:
            # Co-contracción → mantener posición (sin cambio)
            return
        
        if flex_active and not ext_active:
            # Cerrar mano proporcionalmente
            effective = (flexor_level - self.config.activation_threshold) * self.config.sensitivity
            effective = min(1.0, effective / (1.0 - self.config.activation_threshold))
            self._current_grip_level = min(1.0, 
                self._current_grip_level + effective * self.config.max_grip_speed * self._dt)
            
        elif ext_active and not flex_active:
            # Abrir mano
            effective = (extensor_level - self.config.activation_threshold) * self.config.sensitivity
            effective = min(1.0, effective / (1.0 - self.config.activation_threshold))
            self._current_grip_level = max(0.0,
                self._current_grip_level - effective * self.config.max_grip_speed * self._dt)
        
        # Aplicar nivel de agarre
        self.hand.apply_grip_pattern(self.state.current_grip, self._current_grip_level)
        
        # Control del pulgar
        if thumb_level > self.config.activation_threshold:
            thumb_flex = (thumb_level - self.config.activation_threshold) / \
                        (1.0 - self.config.activation_threshold)
            self.hand.set_finger_flexion(FingerName.THUMB, thumb_flex)
    
    def _process_pattern_control(self, signals: Dict[MuscleGroup, EMGSignal]):
        """
        Reconocimiento de patrones EMG simple.
        Detecta combinaciones de activación muscular.
        """
        flex  = signals[MuscleGroup.FLEXOR_FINGERS].activation_level
        ext   = signals[MuscleGroup.EXTENSOR_FINGERS].activation_level
        thumb = signals[MuscleGroup.FLEXOR_THUMB].activation_level
        abd   = signals[MuscleGroup.ABDUCTOR_THUMB].activation_level
        lat   = signals[MuscleGroup.LATERAL_PINCH].activation_level
        
        th = self.config.activation_threshold
        
        # Tabla de reconocimiento de patrones
        # (patrón si condición)
        detected = None
        
        if flex > 0.7 and ext < th and thumb > 0.5:
            detected = GripPattern.POWER_GRIP
        elif flex > 0.5 and thumb > 0.6 and ext < th:
            detected = GripPattern.PINCH_TIP
        elif lat > 0.5 and thumb > 0.4:
            detected = GripPattern.PINCH_LATERAL
        elif flex > 0.6 and abd > 0.5:
            detected = GripPattern.TRIPOD
        elif ext > 0.6 and flex < th:
            detected = GripPattern.OPEN
        elif flex > 0.4 and thumb < th:
            detected = GripPattern.HOOK
        
        if detected and detected != self.state.current_grip:
            self.state.current_grip = detected
            self.hand.apply_grip_pattern(detected, 0.9)
            if self.on_pattern_detected:
                self.on_pattern_detected(detected)
            self._log(f"Patrón detectado: {detected.value}")
    
    def _process_demo(self):
        """Ejecuta secuencia de demostración automática."""
        step = self.demo.get_current_step()
        if step:
            pattern, force = step
            if pattern != self.state.current_grip:
                self.state.current_grip = pattern
                self.hand.apply_grip_pattern(pattern, force)
    
    # ── Métodos de control manual (llamados desde GUI) ──────────────────
    
    def set_mode(self, mode: ControlMode):
        """Cambia modo de control."""
        self.state.mode = mode
        if mode == ControlMode.AUTO_DEMO:
            self.demo.reset()
        elif mode == ControlMode.MANUAL:
            self.hand.apply_grip_pattern(GripPattern.OPEN)
            self._current_grip_level = 0.0
        self._log(f"Modo: {mode.value}")
    
    def manual_grip(self, pattern: GripPattern, force: float):
        """Aplica patrón de agarre manualmente."""
        if self.state.mode == ControlMode.MANUAL:
            self.state.current_grip = pattern
            self.hand.apply_grip_pattern(pattern, force)
            self.state.command_count += 1
    
    def manual_set_finger(self, finger: FingerName, level: float):
        """Control manual de dedo individual."""
        if self.state.mode == ControlMode.MANUAL:
            self.hand.set_finger_flexion(finger, level)
    
    def set_emg_muscle(self, muscle: MuscleGroup, level: float):
        """Establece activación de un músculo EMG (para simulación)."""
        self.sensors.set_muscle_activation(muscle, level)
    
    def set_wrist(self, angle: float):
        """Control de muñeca."""
        self.hand.set_wrist(angle)
        self.state.wrist_position = angle
    
    def get_telemetry(self) -> dict:
        """Retorna datos de telemetría del sistema."""
        session_time = time.time() - self.state.session_start
        fatigue = self.sensors.get_fatigue_levels()
        
        return {
            "mode": self.state.mode.value,
            "grip_pattern": self.state.current_grip.value,
            "grip_pct": self.hand.get_grip_percentage(),
            "wrist_angle": self.hand.wrist_angle,
            "session_time": session_time,
            "command_count": self.state.command_count,
            "fatigue": {m.value: v for m, v in fatigue.items()},
            "finger_angles": {
                name.value: angles 
                for name, angles in self.hand.get_finger_angles().items()
            }
        }
    
    def _log(self, message: str):
        """Añade entrada al log de eventos."""
        timestamp = time.strftime("%H:%M:%S")
        entry = f"[{timestamp}] {message}"
        self.event_log.append(entry)
        if len(self.event_log) > self._max_log:
            self.event_log.pop(0)
    
    def get_log(self, n: int = 10) -> List[str]:
        return self.event_log[-n:]
    
    def reset_session(self):
        """Reinicia la sesión."""
        self.state.command_count = 0
        self.state.session_start = time.time()
        self.sensors.reset_fatigue()
        self.hand.apply_grip_pattern(GripPattern.OPEN)
        self._current_grip_level = 0.0
        self._log("Sesión reiniciada")
